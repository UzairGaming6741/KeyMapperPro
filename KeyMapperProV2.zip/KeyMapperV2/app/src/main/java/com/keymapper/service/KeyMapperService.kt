package com.keymapper.service

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.keymapper.engine.GameController
import com.keymapper.overlay.OverlayManager
import com.keymapper.profile.GameProfile
import com.keymapper.profile.ProfileManager

class KeyMapperService : AccessibilityService() {

    companion object {
        const val TAG = "KMService"
        const val ACTION_START   = "com.keymapper.START"
        const val ACTION_STOP    = "com.keymapper.STOP"
        const val ACTION_TOGGLE  = "com.keymapper.TOGGLE"
        const val ACTION_PROFILE = "com.keymapper.PROFILE"
        const val EXTRA_PROFILE_ID = "pid"

        @Volatile var instance: KeyMapperService? = null
        val isRunning get() = instance != null
    }

    private lateinit var profileManager: ProfileManager
    private lateinit var overlayManager: OverlayManager
    private var controller: GameController? = null
    private var currentProfile: GameProfile? = null
    private var screenW = 1920; private var screenH = 1080

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_START   -> startMapping()
                ACTION_STOP    -> stopMapping()
                ACTION_TOGGLE  -> toggleMapping()
                ACTION_PROFILE -> {
                    val id = intent.getStringExtra(EXTRA_PROFILE_ID) ?: return
                    loadProfile(id)
                }
            }
        }
    }

    override fun onServiceConnected() {
        instance = this
        resolveScreen()
        profileManager = ProfileManager(this)
        profileManager.ensureDefaults()
        overlayManager = OverlayManager(this)

        val filter = IntentFilter().apply {
            addAction(ACTION_START); addAction(ACTION_STOP)
            addAction(ACTION_TOGGLE); addAction(ACTION_PROFILE)
        }
        registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        loadProfile("preset_ff") // default
        Log.i(TAG, "Service connected — ${screenW}x${screenH}")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopMapping()
        overlayManager.destroy()
        try { unregisterReceiver(receiver) } catch (e: Exception) {}
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stopMapping() }

    fun loadProfile(id: String) {
        val p = profileManager.load(id) ?: return
        currentProfile = p
        controller?.applyProfile(p)
        Log.i(TAG, "Profile loaded: ${p.name}")
    }

    fun startMapping(): Boolean {
        val p = currentProfile ?: return false
        if (controller?.isRunning() == true) return true

        val ctrl = GameController(screenW, screenH)
        val ok = ctrl.start(p)
        if (ok) {
            controller = ctrl
            overlayManager.showTouchOverlay(p.bindings, screenW, screenH)
            overlayManager.showHud(true, true)
            Log.i(TAG, "Mapping STARTED")
        } else {
            Log.e(TAG, "Failed to start controller")
        }
        return ok
    }

    fun stopMapping() {
        controller?.stop()
        controller = null
        overlayManager.hideTouchOverlay()
        overlayManager.showHud(false, false)
        Log.i(TAG, "Mapping STOPPED")
    }

    fun toggleMapping() {
        if (controller?.isRunning() == true) stopMapping() else startMapping()
    }

    fun isMappingActive() = controller?.isRunning() == true
    fun getCurrentProfile() = currentProfile

    private fun resolveScreen() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width(); screenH = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels; screenH = dm.heightPixels
        }
    }
}
