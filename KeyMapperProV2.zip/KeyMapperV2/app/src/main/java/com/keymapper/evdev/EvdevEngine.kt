package com.keymapper.evdev

import android.util.Log

object EvdevEngine {
    private const val TAG = "EvdevEngine"
    var loaded = false
        private set

    init {
        try {
            System.loadLibrary("keymapper_native")
            loaded = true
            Log.i(TAG, "Native lib loaded")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Native lib FAILED: ${e.message}")
        }
    }

    // Lifecycle
    external fun nativeStart(screenW: Int, screenH: Int): Int
    external fun nativeStop()
    external fun nativeSetMouseLock(lock: Boolean)
    external fun nativeSetConfig(sens: Float, accel: Float, dz: Float, sw: Int, sh: Int)
    external fun nativeIsMouseLocked(): Boolean

    // Polling — zero-alloc scratch arrays
    external fun nativePollMouse(outDxDy: FloatArray, outButtons: BooleanArray): Boolean
    external fun nativePollKey(outCodeVal: IntArray): Boolean
    external fun nativePollTouch(outType: IntArray, outId: IntArray, outX: FloatArray, outY: FloatArray): Boolean
}
