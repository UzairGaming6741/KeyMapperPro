package com.keymapper.evdev

object MouseLock {
    external fun nativeHideCursor()
    external fun nativeShowCursor()
    external fun nativeSetPointerSpeed(speed: Int)
    external fun nativeWarpCursorToCenter(screenW: Int, screenH: Int)
}
