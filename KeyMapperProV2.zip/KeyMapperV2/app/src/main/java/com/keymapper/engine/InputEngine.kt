package com.keymapper.engine

object InputEngine {
    external fun nativeSetLayout(
        aimCX: Float, aimCY: Float,
        joyCX: Float, joyCY: Float, joyR: Float,
        shootX: Float, shootY: Float,
        scopeX: Float, scopeY: Float
    )
    external fun nativeSetButtonPos(idx: Int, x: Float, y: Float)
    external fun nativeOnMouseDelta(rawDx: Float, rawDy: Float)
    external fun nativeStopAim()
    external fun nativeOnMouseButton(
        leftDown: Boolean, leftUp: Boolean,
        rightDown: Boolean, rightUp: Boolean
    )
    external fun nativeOnKey(code: Int, value: Int)
    external fun nativeButtonDown(slotIdx: Int, x: Float, y: Float)
    external fun nativeButtonUp(slotIdx: Int)
    external fun nativeReleaseAll()
}
