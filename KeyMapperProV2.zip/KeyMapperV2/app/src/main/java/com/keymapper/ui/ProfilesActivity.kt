package com.keymapper.ui

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.keymapper.R
import com.keymapper.databinding.ActivityProfilesBinding
import com.keymapper.databinding.ActivitySettingsBinding
import com.keymapper.profile.GameProfile
import com.keymapper.profile.ProfileManager
import com.keymapper.service.KeyMapperService

// ── Profiles Activity ─────────────────────────────────────────────────────────
class ProfilesActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfilesBinding
    private lateinit var pm: ProfileManager
    private val profiles = mutableListOf<GameProfile>()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        binding = ActivityProfilesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Profiles"
        pm = ProfileManager(this)

        val adapter = object : ArrayAdapter<GameProfile>(this, android.R.layout.simple_list_item_2, profiles) {
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val v = cv ?: LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false)
                val p = profiles[pos]
                v.findViewById<TextView>(android.R.id.text1)?.text = p.name
                v.findViewById<TextView>(android.R.id.text2)?.text =
                    "Sens: ${"%.1f".format(p.sensitivity)}  •  ${p.bindings.size} bindings  •  ${if(p.id.startsWith("preset_")) "PRESET" else "Custom"}"
                return v
            }
        }
        binding.listProfiles.adapter = adapter

        binding.listProfiles.setOnItemClickListener { _, _, pos, _ ->
            val p = profiles[pos]
            KeyMapperService.instance?.loadProfile(p.id)
                ?: getSharedPreferences("km", MODE_PRIVATE).edit().putString("last_profile", p.id).apply()
            Toast.makeText(this, "Loaded: ${p.name}", Toast.LENGTH_SHORT).show()
        }

        binding.listProfiles.setOnItemLongClickListener { _, v, pos, _ ->
            val p = profiles[pos]
            PopupMenu(this, v).apply {
                menu.add("Load")
                menu.add("Edit Layout")
                if (!p.id.startsWith("preset_")) menu.add("Delete")
                setOnMenuItemClickListener { item ->
                    when (item.title) {
                        "Load" -> { KeyMapperService.instance?.loadProfile(p.id); Toast.makeText(this@ProfilesActivity, "Loaded", Toast.LENGTH_SHORT).show() }
                        "Edit Layout" -> { KeyMapperService.instance?.loadProfile(p.id); startActivity(Intent(this@ProfilesActivity, EditorActivity::class.java)) }
                        "Delete" -> { pm.delete(p.id); refresh(adapter) }
                    }
                    true
                }
                show()
            }
            true
        }

        refresh(adapter)
    }

    private fun refresh(adapter: ArrayAdapter<GameProfile>) {
        profiles.clear(); profiles.addAll(pm.list()); adapter.notifyDataSetChanged()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}

// ── Settings Activity ─────────────────────────────────────────────────────────
class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var pm: ProfileManager

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Settings"
        pm = ProfileManager(this)

        val p = KeyMapperService.instance?.getCurrentProfile()
        binding.sliderSens.value  = p?.sensitivity  ?: 1.8f
        binding.sliderAccel.value = p?.acceleration ?: 0.3f
        binding.sliderDz.value    = p?.deadzone     ?: 0.1f
        updateLabels()

        binding.sliderSens.addOnChangeListener  { _, _, _ -> updateLabels() }
        binding.sliderAccel.addOnChangeListener { _, _, _ -> updateLabels() }
        binding.sliderDz.addOnChangeListener    { _, _, _ -> updateLabels() }

        binding.btnApply.setOnClickListener { applySettings() }
        binding.btnSaveNew.setOnClickListener { saveNewProfile() }
    }

    private fun updateLabels() {
        binding.tvSensVal.text  = "%.2f".format(binding.sliderSens.value)
        binding.tvAccelVal.text = "%.2f".format(binding.sliderAccel.value)
        binding.tvDzVal.text    = "%.2f".format(binding.sliderDz.value)
    }

    private fun applySettings() {
        val svc = KeyMapperService.instance ?: run { Toast.makeText(this, "Service not running", Toast.LENGTH_SHORT).show(); return }
        val p = svc.getCurrentProfile() ?: return
        val updated = p.copy(
            sensitivity  = binding.sliderSens.value,
            acceleration = binding.sliderAccel.value,
            deadzone     = binding.sliderDz.value
        )
        pm.save(updated)
        svc.loadProfile(updated.id)
        Toast.makeText(this, "Settings applied", Toast.LENGTH_SHORT).show()
    }

    private fun saveNewProfile() {
        val name = binding.etName.text.toString().trim()
        if (name.isEmpty()) { binding.etName.error = "Enter name"; return }
        val base = KeyMapperService.instance?.getCurrentProfile() ?: pm.load("preset_ff") ?: return
        val newP = base.copy(
            id = "custom_${System.currentTimeMillis()}",
            name = name,
            sensitivity  = binding.sliderSens.value,
            acceleration = binding.sliderAccel.value,
            deadzone     = binding.sliderDz.value
        )
        pm.save(newP)
        Toast.makeText(this, "Saved: $name", Toast.LENGTH_SHORT).show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}
