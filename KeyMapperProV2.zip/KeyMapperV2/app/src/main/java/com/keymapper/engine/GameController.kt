package com.keymapper.engine

import android.util.Log
import com.keymapper.evdev.EvdevEngine
import com.keymapper.evdev.MouseLock
import com.keymapper.evdev.UInputTouch
import com.keymapper.profile.GameProfile
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * GameController — the master runtime loop.
 *
 * Architecture:
 *   1. EvdevEngine reads raw mouse+key events from /dev/input (kernel level)
 *   2. InputEngine.nativeOnMouseDelta converts deltas → touch positions
 *   3. UInputTouch injects touch events into /dev/uinput (kernel level)
 *   4. Game receives clean multitouch — no cursor visible, no lag
 *
 * Mouse lock cycle:
 *   - Mouse is GRABBED via EVIOCGRAB = Android cursor system sees NOTHING
 *   - All movement goes through our raw delta tracker
 *   - Right-Alt or configured toggle key unlocks temporarily for menus
 */
class GameController(
    private var screenW: Int,
    private var screenH: Int
) {
    companion object { const val TAG = "GameController" }

    private val running  = AtomicBoolean(false)
    private val scope    = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Mouse idle watchdog
    private val lastMouseMoveMs = AtomicLong(0L)
    private var watchdogJob: Job? = null

    // Current profile
    private var profile: GameProfile? = null
    private var bindings: List<KeyBinding> = emptyList()

    // Key→binding lookup by linux keycode
    private val keyMap = HashMap<Int, KeyBinding>(64)

    // Scratch arrays (reused every poll — zero GC)
    private val outDxDy    = FloatArray(2)
    private val outButtons = BooleanArray(4)
    private val outCodeVal = IntArray(2)
    private val outType    = IntArray(1)
    private val outId      = IntArray(1)
    private val outX       = FloatArray(1)
    private val outY       = FloatArray(1)

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    fun start(p: GameProfile): Boolean {
        if (running.get()) stop()
        profile = p
        applyProfile(p)

        // 1. Start evdev reader (root required)
        val result = EvdevEngine.nativeStart(screenW, screenH)
        if (result != 0) {
            Log.e(TAG, "EvdevEngine.start failed: $result")
            return false
        }

        // 2. Create uinput virtual touch device
        val uiResult = UInputTouch.nativeCreate(screenW, screenH)
        if (uiResult != 0) {
            Log.e(TAG, "UInputTouch.create failed: $uiResult")
            EvdevEngine.nativeStop()
            return false
        }

        // 3. Lock mouse (grab device)
        EvdevEngine.nativeSetMouseLock(true)
        MouseLock.nativeHideCursor()

        running.set(true)

        // 4. Start poll loop
        startPollLoop()
        startMouseWatchdog()

        Log.i(TAG, "GameController STARTED — profile: ${p.name}")
        return true
    }

    fun stop() {
        if (!running.get()) return
        running.set(false)

        watchdogJob?.cancel()

        InputEngine.nativeReleaseAll()
        drainTouchQueue()

        EvdevEngine.nativeSetMouseLock(false)
        MouseLock.nativeShowCursor()
        MouseLock.nativeSetPointerSpeed(0)

        EvdevEngine.nativeStop()
        UInputTouch.nativeDestroy()

        scope.cancel()
        Log.i(TAG, "GameController STOPPED")
    }

    fun applyProfile(p: GameProfile) {
        profile = p
        bindings = p.bindings
        keyMap.clear()
        bindings.forEach { b -> if (b.linuxKeyCode > 0) keyMap[b.linuxKeyCode] = b }

        val aimCX   = p.aimCenterX * screenW
        val aimCY   = p.aimCenterY * screenH
        val joyCX   = p.joyCenterX * screenW
        val joyCY   = p.joyCenterY * screenH
        val joyR    = p.joyRadius  * screenH
        val shootX  = p.shootX * screenW
        val shootY  = p.shootY * screenH
        val scopeX  = p.scopeX * screenW
        val scopeY  = p.scopeY * screenH

        InputEngine.nativeSetLayout(
            aimCX, aimCY, joyCX, joyCY, joyR,
            shootX, shootY, scopeX, scopeY
        )
        EvdevEngine.nativeSetConfig(p.sensitivity, p.acceleration, p.deadzone, screenW, screenH)

        // Set button positions
        bindings.filter { it.slotIndex in 0..5 }.forEach { b ->
            InputEngine.nativeSetButtonPos(b.slotIndex, b.touchX * screenW, b.touchY * screenH)
        }
        Log.i(TAG, "Profile applied: ${p.name}")
    }

    fun updateScreenSize(w: Int, h: Int) {
        screenW = w; screenH = h
        profile?.let { applyProfile(it) }
        EvdevEngine.nativeSetConfig(
            profile?.sensitivity ?: 1.8f,
            profile?.acceleration ?: 0.3f,
            profile?.deadzone ?: 0.1f, w, h
        )
    }

    // ── Main poll loop (~1000Hz) ──────────────────────────────────────────────
    private fun startPollLoop() {
        scope.launch(Dispatchers.Default) {
            while (running.get()) {
                var busy = false

                // 1. Poll mouse events
                while (EvdevEngine.nativePollMouse(outDxDy, outButtons)) {
                    val dx = outDxDy[0]; val dy = outDxDy[1]
                    if (dx != 0f || dy != 0f) {
                        InputEngine.nativeOnMouseDelta(dx, dy)
                        lastMouseMoveMs.set(System.currentTimeMillis())
                    }
                    if (outButtons[0] || outButtons[1] || outButtons[2] || outButtons[3]) {
                        InputEngine.nativeOnMouseButton(
                            outButtons[0], outButtons[1],
                            outButtons[2], outButtons[3]
                        )
                    }
                    busy = true
                }

                // 2. Poll key events
                while (EvdevEngine.nativePollKey(outCodeVal)) {
                    processKey(outCodeVal[0], outCodeVal[1])
                    busy = true
                }

                // 3. Drain touch queue → uinput
                drainTouchQueue()

                // Adaptive sleep
                if (!busy) Thread.sleep(0, 300_000) // 0.3ms
            }
        }
    }

    // ── Key processing ────────────────────────────────────────────────────────
    private fun processKey(code: Int, value: Int) {
        // value: 1=press, 0=release, 2=repeat
        InputEngine.nativeOnKey(code, value)

        // Handle button bindings
        val binding = keyMap[code] ?: return
        when (binding.actionType) {
            ActionType.TAP, ActionType.HOLD -> {
                if (value == 1 && binding.slotIndex in 0..5) {
                    InputEngine.nativeButtonDown(
                        binding.slotIndex,
                        binding.touchX * screenW,
                        binding.touchY * screenH
                    )
                } else if (value == 0 && binding.slotIndex in 0..5) {
                    InputEngine.nativeButtonUp(binding.slotIndex)
                }
            }
            else -> {} // JOYSTICK/AIM/SHOOT/SCOPE handled natively
        }
    }

    // ── Touch queue → uinput injection ────────────────────────────────────────
    private var trackIdCounter = 100

    private fun drainTouchQueue() {
        if (!UInputTouch.nativeIsReady()) return
        while (EvdevEngine.nativePollTouch(outType, outId, outX, outY)) {
            val type = outType[0]
            val slot = outId[0]
            val x    = outX[0].toInt()
            val y    = outY[0].toInt()
            when (type) {
                0 -> UInputTouch.nativeTouchDown(slot, trackIdCounter++, x, y)
                1 -> UInputTouch.nativeTouchMove(slot, x, y)
                2 -> UInputTouch.nativeTouchUp(slot)
            }
        }
    }

    // ── Mouse idle watchdog ────────────────────────────────────────────────────
    private fun startMouseWatchdog() {
        watchdogJob = scope.launch {
            while (isActive && running.get()) {
                delay(16)
                val last = lastMouseMoveMs.get()
                if (last > 0 && System.currentTimeMillis() - last > 60) {
                    InputEngine.nativeStopAim()
                    lastMouseMoveMs.set(0)
                }
            }
        }
    }

    fun isRunning() = running.get()
}
