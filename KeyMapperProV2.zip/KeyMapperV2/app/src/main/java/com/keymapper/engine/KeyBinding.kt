package com.keymapper.engine

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// Linux evdev key codes (from /usr/include/linux/input-event-codes.h)
object LinuxKey {
    const val KEY_W         = 17
    const val KEY_A         = 30
    const val KEY_S         = 31
    const val KEY_D         = 32
    const val KEY_SPACE     = 57
    const val KEY_R         = 19
    const val KEY_F         = 33
    const val KEY_C         = 46
    const val KEY_Z         = 44
    const val KEY_X         = 45
    const val KEY_V         = 47
    const val KEY_B         = 48
    const val KEY_G         = 34
    const val KEY_E         = 18
    const val KEY_Q         = 16
    const val KEY_TAB       = 15
    const val KEY_M         = 50
    const val KEY_1         = 2
    const val KEY_2         = 3
    const val KEY_3         = 4
    const val KEY_4         = 5
    const val KEY_5         = 6
    const val KEY_ESC       = 1
    const val KEY_LEFTSHIFT = 42
    const val KEY_LEFTCTRL  = 29
    const val KEY_T         = 20
    const val KEY_H         = 35
    const val KEY_U         = 22
    const val KEY_I         = 23
    const val KEY_O         = 24
    const val KEY_P         = 25
}

enum class ActionType {
    JOYSTICK,     // WASD virtual joystick
    AIM,          // Mouse aim zone
    SHOOT,        // Left click fire
    SCOPE,        // Right click ADS
    TAP,          // Single tap
    HOLD,         // Hold while key down
    SWIPE_UP,
    SWIPE_DOWN,
}

enum class InputSource {
    KEYBOARD,
    MOUSE_LEFT,
    MOUSE_RIGHT,
    MOUSE_MOVE,
}

@Parcelize
data class KeyBinding(
    val id: String,
    val label: String,
    val linuxKeyCode: Int,          // Linux evdev keycode
    val inputSource: InputSource,
    val actionType: ActionType,
    val touchX: Float,              // 0.0–1.0 normalized
    val touchY: Float,
    val slotIndex: Int = -1,        // btn slot (0-5) for keyboard buttons
    val enabled: Boolean = true
) : Parcelable

// ────────────────────────────────────────────────────────────────────────────
// GAME PRESETS
// All positions are tuned for 16:9 landscape like Free Fire / PUBG Mobile
// ────────────────────────────────────────────────────────────────────────────
object GamePresets {

    // ── Free Fire ────────────────────────────────────────────────────────────
    fun freeFire() = listOf(
        // Movement
        KeyBinding("joy_w",    "W",       LinuxKey.KEY_W,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.68f),
        KeyBinding("joy_a",    "A",       LinuxKey.KEY_A,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.68f),
        KeyBinding("joy_s",    "S",       LinuxKey.KEY_S,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.68f),
        KeyBinding("joy_d",    "D",       LinuxKey.KEY_D,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.68f),
        // Aim
        KeyBinding("aim",      "AIM",     -1,                      InputSource.MOUSE_MOVE,  ActionType.AIM,      0.62f, 0.50f),
        // Combat
        KeyBinding("fire",     "FIRE",    -1,                      InputSource.MOUSE_LEFT,  ActionType.SHOOT,    0.88f, 0.62f),
        KeyBinding("scope",    "SCOPE",   -1,                      InputSource.MOUSE_RIGHT, ActionType.SCOPE,    0.75f, 0.45f),
        // Actions
        KeyBinding("jump",     "Jump",    LinuxKey.KEY_SPACE,      InputSource.KEYBOARD,    ActionType.TAP,      0.88f, 0.50f, slotIndex=0),
        KeyBinding("crouch",   "Crouch",  LinuxKey.KEY_C,          InputSource.KEYBOARD,    ActionType.HOLD,     0.84f, 0.82f, slotIndex=1),
        KeyBinding("prone",    "Prone",   LinuxKey.KEY_Z,          InputSource.KEYBOARD,    ActionType.TAP,      0.84f, 0.90f, slotIndex=2),
        KeyBinding("reload",   "Reload",  LinuxKey.KEY_R,          InputSource.KEYBOARD,    ActionType.TAP,      0.76f, 0.80f, slotIndex=3),
        KeyBinding("loot",     "Loot",    LinuxKey.KEY_F,          InputSource.KEYBOARD,    ActionType.TAP,      0.50f, 0.88f, slotIndex=4),
        KeyBinding("map",      "Map",     LinuxKey.KEY_M,          InputSource.KEYBOARD,    ActionType.TAP,      0.92f, 0.10f, slotIndex=5),
    )

    // ── PUBG Mobile ──────────────────────────────────────────────────────────
    fun pubgMobile() = listOf(
        KeyBinding("joy_w",    "W",       LinuxKey.KEY_W,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.70f),
        KeyBinding("joy_a",    "A",       LinuxKey.KEY_A,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.70f),
        KeyBinding("joy_s",    "S",       LinuxKey.KEY_S,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.70f),
        KeyBinding("joy_d",    "D",       LinuxKey.KEY_D,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.70f),
        KeyBinding("aim",      "AIM",     -1,                      InputSource.MOUSE_MOVE,  ActionType.AIM,      0.62f, 0.50f),
        KeyBinding("fire",     "FIRE",    -1,                      InputSource.MOUSE_LEFT,  ActionType.SHOOT,    0.87f, 0.60f),
        KeyBinding("ads",      "ADS",     -1,                      InputSource.MOUSE_RIGHT, ActionType.SCOPE,    0.74f, 0.44f),
        KeyBinding("jump",     "Jump",    LinuxKey.KEY_SPACE,      InputSource.KEYBOARD,    ActionType.TAP,      0.87f, 0.48f, slotIndex=0),
        KeyBinding("crouch",   "Crouch",  LinuxKey.KEY_C,          InputSource.KEYBOARD,    ActionType.HOLD,     0.83f, 0.80f, slotIndex=1),
        KeyBinding("prone",    "Prone",   LinuxKey.KEY_Z,          InputSource.KEYBOARD,    ActionType.TAP,      0.83f, 0.90f, slotIndex=2),
        KeyBinding("reload",   "Reload",  LinuxKey.KEY_R,          InputSource.KEYBOARD,    ActionType.TAP,      0.76f, 0.78f, slotIndex=3),
        KeyBinding("loot",     "Loot/Use",LinuxKey.KEY_F,          InputSource.KEYBOARD,    ActionType.TAP,      0.50f, 0.88f, slotIndex=4),
        KeyBinding("map",      "Map",     LinuxKey.KEY_M,          InputSource.KEYBOARD,    ActionType.TAP,      0.92f, 0.10f, slotIndex=5),
        KeyBinding("inventory","Bag",     LinuxKey.KEY_TAB,        InputSource.KEYBOARD,    ActionType.TAP,      0.86f, 0.10f, slotIndex=5),
        KeyBinding("vehicle",  "Vehicle", LinuxKey.KEY_V,          InputSource.KEYBOARD,    ActionType.TAP,      0.78f, 0.90f),
        KeyBinding("sprint",   "Sprint",  LinuxKey.KEY_LEFTSHIFT,  InputSource.KEYBOARD,    ActionType.HOLD,     0.12f, 0.55f),
    )

    // ── COD Mobile ───────────────────────────────────────────────────────────
    fun codMobile() = listOf(
        KeyBinding("joy_w",    "W",       LinuxKey.KEY_W,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.14f, 0.70f),
        KeyBinding("joy_a",    "A",       LinuxKey.KEY_A,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.14f, 0.70f),
        KeyBinding("joy_s",    "S",       LinuxKey.KEY_S,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.14f, 0.70f),
        KeyBinding("joy_d",    "D",       LinuxKey.KEY_D,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.14f, 0.70f),
        KeyBinding("aim",      "AIM",     -1,                      InputSource.MOUSE_MOVE,  ActionType.AIM,      0.62f, 0.50f),
        KeyBinding("fire",     "FIRE",    -1,                      InputSource.MOUSE_LEFT,  ActionType.SHOOT,    0.87f, 0.62f),
        KeyBinding("ads",      "ADS",     -1,                      InputSource.MOUSE_RIGHT, ActionType.SCOPE,    0.73f, 0.42f),
        KeyBinding("jump",     "Jump",    LinuxKey.KEY_SPACE,      InputSource.KEYBOARD,    ActionType.TAP,      0.88f, 0.50f, slotIndex=0),
        KeyBinding("crouch",   "Crouch",  LinuxKey.KEY_C,          InputSource.KEYBOARD,    ActionType.HOLD,     0.83f, 0.82f, slotIndex=1),
        KeyBinding("reload",   "Reload",  LinuxKey.KEY_R,          InputSource.KEYBOARD,    ActionType.TAP,      0.76f, 0.80f, slotIndex=2),
        KeyBinding("melee",    "Melee",   LinuxKey.KEY_V,          InputSource.KEYBOARD,    ActionType.TAP,      0.65f, 0.82f, slotIndex=3),
        KeyBinding("grenade",  "Grenade", LinuxKey.KEY_G,          InputSource.KEYBOARD,    ActionType.TAP,      0.55f, 0.82f, slotIndex=4),
        KeyBinding("scorestr", "Score",   LinuxKey.KEY_TAB,        InputSource.KEYBOARD,    ActionType.TAP,      0.92f, 0.10f, slotIndex=5),
    )

    // ── Generic Battle Royale ─────────────────────────────────────────────────
    fun genericBR() = listOf(
        KeyBinding("joy_w",    "W",       LinuxKey.KEY_W,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.70f),
        KeyBinding("joy_a",    "A",       LinuxKey.KEY_A,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.70f),
        KeyBinding("joy_s",    "S",       LinuxKey.KEY_S,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.70f),
        KeyBinding("joy_d",    "D",       LinuxKey.KEY_D,         InputSource.KEYBOARD,    ActionType.JOYSTICK, 0.15f, 0.70f),
        KeyBinding("aim",      "AIM",     -1,                      InputSource.MOUSE_MOVE,  ActionType.AIM,      0.62f, 0.50f),
        KeyBinding("fire",     "FIRE",    -1,                      InputSource.MOUSE_LEFT,  ActionType.SHOOT,    0.87f, 0.62f),
        KeyBinding("scope",    "SCOPE",   -1,                      InputSource.MOUSE_RIGHT, ActionType.SCOPE,    0.74f, 0.44f),
        KeyBinding("jump",     "Jump",    LinuxKey.KEY_SPACE,      InputSource.KEYBOARD,    ActionType.TAP,      0.88f, 0.50f, slotIndex=0),
        KeyBinding("crouch",   "Crouch",  LinuxKey.KEY_C,          InputSource.KEYBOARD,    ActionType.HOLD,     0.83f, 0.80f, slotIndex=1),
        KeyBinding("prone",    "Prone",   LinuxKey.KEY_Z,          InputSource.KEYBOARD,    ActionType.TAP,      0.83f, 0.90f, slotIndex=2),
        KeyBinding("reload",   "Reload",  LinuxKey.KEY_R,          InputSource.KEYBOARD,    ActionType.TAP,      0.76f, 0.78f, slotIndex=3),
        KeyBinding("interact", "Use/Loot",LinuxKey.KEY_F,          InputSource.KEYBOARD,    ActionType.TAP,      0.50f, 0.88f, slotIndex=4),
        KeyBinding("map",      "Map",     LinuxKey.KEY_M,          InputSource.KEYBOARD,    ActionType.TAP,      0.92f, 0.10f, slotIndex=5),
    )
}
