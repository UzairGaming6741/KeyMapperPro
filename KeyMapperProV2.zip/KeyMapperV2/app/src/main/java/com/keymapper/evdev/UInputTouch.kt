package com.keymapper.evdev

object UInputTouch {
    external fun nativeCreate(sw: Int, sh: Int): Int
    external fun nativeDestroy()
    external fun nativeTouchDown(slot: Int, trackingId: Int, x: Int, y: Int)
    external fun nativeTouchMove(slot: Int, x: Int, y: Int)
    external fun nativeTouchUp(slot: Int)
    external fun nativeIsReady(): Boolean
}
