package com.keymapper.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.keymapper.databinding.ActivityMainBinding
import com.keymapper.profile.ProfileManager
import com.keymapper.service.KeyMapperService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var profileManager: ProfileManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        profileManager = ProfileManager(this)
        profileManager.ensureDefaults()
        setupUI()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun setupUI() {
        // Enable service
        binding.btnEnableService.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Toggle mapping
        binding.btnToggle.setOnClickListener {
            val svc = KeyMapperService.instance ?: run {
                toast("Enable Accessibility Service first!"); return@setOnClickListener
            }
            svc.toggleMapping()
            refreshStatus()
        }

        // Game presets
        binding.btnFreeFire.setOnClickListener  { loadPreset("preset_ff",   "Free Fire") }
        binding.btnPubg.setOnClickListener      { loadPreset("preset_pubg", "PUBG Mobile") }
        binding.btnCod.setOnClickListener       { loadPreset("preset_cod",  "COD Mobile") }
        binding.btnGenericBr.setOnClickListener { loadPreset("preset_br",   "Generic BR") }

        // Overlay editor
        binding.btnEditor.setOnClickListener {
            startActivity(Intent(this, EditorActivity::class.java))
        }

        // Profiles
        binding.btnProfiles.setOnClickListener {
            startActivity(Intent(this, ProfilesActivity::class.java))
        }

        // Settings
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // Sensitivity slider
        binding.sliderSensitivity.addOnChangeListener { _, v, _ ->
            binding.tvSensValue.text = "%.1fx".format(v)
        }
    }

    private fun loadPreset(id: String, name: String) {
        val svc = KeyMapperService.instance
        if (svc != null) {
            svc.loadProfile(id)
            toast("$name loaded")
        } else {
            // Save preference so service loads it when started
            getSharedPreferences("km", MODE_PRIVATE).edit().putString("last_profile", id).apply()
            toast("$name selected — start mapping when ready")
        }
        refreshStatus()
    }

    private fun refreshStatus() {
        val serviceOk  = isServiceEnabled()
        val mapping    = KeyMapperService.instance?.isMappingActive() == true
        val profile    = KeyMapperService.instance?.getCurrentProfile()

        binding.tvServiceStatus.text  = if (serviceOk) "✓ Service Active"   else "✗ Enable Service"
        binding.tvServiceStatus.setTextColor(
            if (serviceOk) getColor(android.R.color.holo_green_light)
            else           getColor(android.R.color.holo_red_light)
        )
        binding.tvMappingStatus.text  = if (mapping) "● MAPPING ON" else "○ Mapping Off"
        binding.tvMappingStatus.setTextColor(
            if (mapping) getColor(android.R.color.holo_green_light)
            else         getColor(android.R.color.darker_gray)
        )
        binding.tvProfile.text = profile?.name ?: "No profile selected"
        binding.btnToggle.text = if (mapping) "■ Stop Mapping" else "▶ Start Mapping"
        binding.btnEnableService.isEnabled = !serviceOk
    }

    private fun isServiceEnabled(): Boolean {
        val services = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return services.contains(packageName)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
