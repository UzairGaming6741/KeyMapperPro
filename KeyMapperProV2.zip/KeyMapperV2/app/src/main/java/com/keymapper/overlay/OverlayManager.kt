package com.keymapper.overlay

import android.content.Context
import android.graphics.*
import android.os.Build
import android.view.*
import com.keymapper.engine.KeyBinding
import com.keymapper.engine.InputSource

class OverlayManager(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: OverlayView? = null
    private var hudView: HudView? = null

    private fun overlayParams(w: Int = WindowManager.LayoutParams.MATCH_PARENT,
                               h: Int = WindowManager.LayoutParams.MATCH_PARENT) =
        WindowManager.LayoutParams(w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT)

    fun showTouchOverlay(bindings: List<KeyBinding>, sw: Int, sh: Int) {
        hideTouchOverlay()
        val v = OverlayView(ctx, bindings, sw, sh)
        try { wm.addView(v, overlayParams()); overlayView = v } catch (e: Exception) {}
    }

    fun hideTouchOverlay() {
        overlayView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        overlayView = null
    }

    fun showHud(active: Boolean, locked: Boolean) {
        if (hudView == null) {
            val h = HudView(ctx)
            val p = overlayParams(200, 60).apply {
                gravity = Gravity.TOP or Gravity.END
                topMargin = 20; rightMargin = 20
                flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            try { wm.addView(h, p); hudView = h } catch (e: Exception) {}
        }
        hudView?.update(active, locked)
    }

    fun hideHud() {
        hudView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        hudView = null
    }

    fun destroy() { hideTouchOverlay(); hideHud() }
}

// ── Touch point overlay ───────────────────────────────────────────────────────
class OverlayView(ctx: Context, bindings: List<KeyBinding>, sw: Int, sh: Int) : View(ctx) {

    data class Dot(val x: Float, val y: Float, val label: String, val color: Int)

    private val dots = bindings.map { b ->
        val color = when (b.inputSource) {
            InputSource.MOUSE_LEFT  -> Color.argb(160, 255, 60,  60)
            InputSource.MOUSE_RIGHT -> Color.argb(160, 255, 165, 0)
            InputSource.MOUSE_MOVE  -> Color.argb(100, 0,   200, 255)
            InputSource.KEYBOARD    -> Color.argb(130, 80,  200, 80)
        }
        Dot(b.touchX * sw, b.touchY * sh, b.label, color)
    }

    private val fill   = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f; color = Color.WHITE }
    private val text   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 24f; typeface = Typeface.DEFAULT_BOLD }

    override fun onDraw(canvas: Canvas) {
        dots.forEach { d ->
            fill.color = d.color
            canvas.drawCircle(d.x, d.y, 38f, fill)
            canvas.drawCircle(d.x, d.y, 38f, border)
            canvas.drawText(d.label, d.x, d.y + 8f, text)
        }
    }
}

// ── HUD status bar ────────────────────────────────────────────────────────────
class HudView(ctx: Context) : View(ctx) {
    private var active = false
    private var locked = false
    private val bg   = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 22f; typeface = Typeface.MONOSPACE }

    fun update(a: Boolean, l: Boolean) { active = a; locked = l; invalidate() }

    override fun onDraw(canvas: Canvas) {
        bg.color = Color.argb(180, 0, 0, 0)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 12f, 12f, bg)
        val dot  = if (active) "●" else "○"
        val lock = if (locked) "🔒" else "🔓"
        val col  = if (active) Color.rgb(0, 220, 80) else Color.GRAY
        txt.color = col
        canvas.drawText("$dot KM  $lock", 12f, height * 0.68f, txt)
    }
}
