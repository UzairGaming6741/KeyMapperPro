package com.keymapper.profile

import android.content.Context
import com.google.gson.Gson
import com.keymapper.engine.GamePresets
import com.keymapper.engine.KeyBinding
import java.io.File

data class GameProfile(
    val id: String,
    val name: String,
    val gamePackage: String = "",
    val bindings: List<KeyBinding>,
    // Sensitivity
    val sensitivity: Float  = 1.8f,
    val acceleration: Float = 0.3f,
    val deadzone: Float     = 0.10f,
    // Layout (normalized 0-1)
    val aimCenterX: Float   = 0.62f,
    val aimCenterY: Float   = 0.50f,
    val joyCenterX: Float   = 0.15f,
    val joyCenterY: Float   = 0.70f,
    val joyRadius: Float    = 0.11f,
    val shootX: Float       = 0.88f,
    val shootY: Float       = 0.62f,
    val scopeX: Float       = 0.75f,
    val scopeY: Float       = 0.44f,
    val createdAt: Long     = System.currentTimeMillis()
)

class ProfileManager(private val ctx: Context) {
    private val gson = Gson()
    private val dir  = File(ctx.filesDir, "profiles").also { it.mkdirs() }

    fun save(p: GameProfile)   { File(dir, "${p.id}.json").writeText(gson.toJson(p)) }
    fun delete(id: String)     { File(dir, "$id.json").delete() }
    fun load(id: String): GameProfile? {
        val f = File(dir, "$id.json")
        return if (f.exists()) try { gson.fromJson(f.readText(), GameProfile::class.java) } catch(e:Exception){ null } else null
    }
    fun list(): List<GameProfile> =
        dir.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { f -> try { gson.fromJson(f.readText(), GameProfile::class.java) } catch(e:Exception){ null } }
            ?.sortedBy { it.createdAt } ?: emptyList()

    fun ensureDefaults() {
        if (load("preset_ff")   == null) save(GameProfile("preset_ff",   "Free Fire",         "com.dts.freefireth",        GamePresets.freeFire()))
        if (load("preset_pubg") == null) save(GameProfile("preset_pubg", "PUBG Mobile",       "com.tencent.ig",            GamePresets.pubgMobile()))
        if (load("preset_cod")  == null) save(GameProfile("preset_cod",  "COD Mobile",        "com.activision.callofduty", GamePresets.codMobile()))
        if (load("preset_br")   == null) save(GameProfile("preset_br",   "Generic BR",        "",                          GamePresets.genericBR()))
    }
}
