package com.keymapper.ui

import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.keymapper.databinding.ActivityEditorBinding
import com.keymapper.engine.KeyBinding
import com.keymapper.engine.InputSource
import com.keymapper.profile.GameProfile
import com.keymapper.profile.ProfileManager
import com.keymapper.service.KeyMapperService

class EditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditorBinding
    private lateinit var pm: ProfileManager
    private var profile: GameProfile? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        pm = ProfileManager(this)
        profile = KeyMapperService.instance?.getCurrentProfile()
            ?: pm.load("preset_ff")

        val canvas = EditorCanvas(this, profile!!.bindings) { updated ->
            profile = profile!!.copy(bindings = updated)
        }
        binding.canvasContainer.addView(canvas)

        binding.btnSave.setOnClickListener {
            profile?.let { p ->
                pm.save(p)
                KeyMapperService.instance?.loadProfile(p.id)
                Toast.makeText(this, "Layout saved!", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnReset.setOnClickListener {
            profile?.let { p ->
                // reload from disk
                pm.load(p.id)?.let { fresh ->
                    canvas.reset(fresh.bindings)
                }
            }
        }
        binding.btnBack.setOnClickListener { finish() }
    }
}

class EditorCanvas(
    ctx: Context,
    initialBindings: List<KeyBinding>,
    private val onChange: (List<KeyBinding>) -> Unit
) : View(ctx) {

    private data class Node(val b: KeyBinding, var nx: Float, var ny: Float)

    private val nodes = initialBindings.map { Node(it, it.touchX, it.touchY) }.toMutableList()
    private var dragging: Node? = null
    private var offX = 0f; private var offY = 0f

    // Paints
    private val fills = mapOf(
        InputSource.KEYBOARD    to Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.argb(170, 60, 180, 60) },
        InputSource.MOUSE_LEFT  to Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.argb(170, 220, 60, 60) },
        InputSource.MOUSE_RIGHT to Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.argb(170, 220, 140, 0) },
        InputSource.MOUSE_MOVE  to Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.argb(100, 0, 180, 255) },
    )
    private val selectedFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.argb(220, 0, 180, 255) }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.WHITE }
    private val txtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 26f; typeface = Typeface.DEFAULT_BOLD }
    private val gridPaint = Paint().apply { color = Color.argb(20, 255, 255, 255); strokeWidth = 1f }
    private val bgPaint = Paint().apply { color = Color.argb(40, 0, 0, 0) }

    private val RADIUS = 44f

    fun reset(bindings: List<KeyBinding>) {
        nodes.clear()
        nodes.addAll(bindings.map { Node(it, it.touchX, it.touchY) })
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        // Grid
        val gs = width / 24f
        var x = gs; while (x < width)  { canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint); x += gs }
        var y = gs; while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, gridPaint); y += gs }

        nodes.forEach { n ->
            val px = n.nx * width; val py = n.ny * height
            val fill = if (n == dragging) selectedFill else fills[n.b.inputSource] ?: fills[InputSource.KEYBOARD]!!
            canvas.drawCircle(px, py, RADIUS, fill)
            canvas.drawCircle(px, py, RADIUS, border)
            canvas.drawText(n.b.label, px, py + 9f, txtPaint)
        }

        // Legend
        txtPaint.textSize = 18f; txtPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("Drag buttons to reposition  •  Long press to delete", 16f, height - 12f, txtPaint)
        txtPaint.textSize = 26f; txtPaint.textAlign = Paint.Align.CENTER
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val nx = e.x / width; val ny = e.y / height
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = nearest(e.x, e.y)
                dragging?.let { offX = nx - it.nx; offY = ny - it.ny }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                dragging?.let {
                    it.nx = (nx - offX).coerceIn(0.02f, 0.98f)
                    it.ny = (ny - offY).coerceIn(0.02f, 0.98f)
                    invalidate()
                    onChange(currentBindings())
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = null; invalidate()
            }
        }
        return true
    }

    private fun nearest(px: Float, py: Float): Node? {
        return nodes.minByOrNull {
            val dx = it.nx * width - px; val dy = it.ny * height - py
            dx*dx + dy*dy
        }?.takeIf {
            val dx = it.nx * width - px; val dy = it.ny * height - py
            Math.sqrt((dx*dx + dy*dy).toDouble()) < RADIUS * 1.5
        }
    }

    private fun currentBindings() = nodes.map {
        it.b.copy(touchX = it.nx.coerceIn(0f, 1f), touchY = it.ny.coerceIn(0f, 1f))
    }
}
