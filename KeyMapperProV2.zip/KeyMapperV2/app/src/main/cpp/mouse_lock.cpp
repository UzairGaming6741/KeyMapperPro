/**
 * mouse_lock.cpp
 *
 * Hides/shows the Android mouse cursor using root shell commands.
 * On POSROG/Android-x86 the cursor is controlled via pointer speed
 * and device grab.  We use both methods for maximum compatibility.
 */
#include "native.h"

static void runShell(const char* cmd) {
    FILE* p = popen(cmd, "r");
    if (p) pclose(p);
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_MouseLock_nativeHideCursor(JNIEnv*, jobject) {
    // Method 1: Set pointer speed to 0 via settings (hides visual cursor movement)
    runShell("su -c 'settings put system pointer_speed -7'");
    // Method 2: Disable pointer location overlay
    runShell("su -c 'settings put system show_touches 0'");
    // Method 3: Write to cursor visibility sysfs if available
    runShell("su -c 'echo 0 > /sys/class/input/mouse*/enable 2>/dev/null'");
    LOGI("Cursor hidden");
}

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_MouseLock_nativeShowCursor(JNIEnv*, jobject) {
    runShell("su -c 'settings put system pointer_speed 0'");
    LOGI("Cursor shown");
}

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_MouseLock_nativeSetPointerSpeed(JNIEnv*, jobject, jint speed) {
    char cmd[128];
    snprintf(cmd, sizeof(cmd), "su -c 'settings put system pointer_speed %d'", speed);
    runShell(cmd);
}

// Warp cursor to center of screen (keeps it from escaping during slow moves)
JNIEXPORT void JNICALL
Java_com_keymapper_evdev_MouseLock_nativeWarpCursorToCenter(JNIEnv*, jobject,
        jint screenW, jint screenH) {
    char cmd[256];
    snprintf(cmd, sizeof(cmd),
        "su -c 'input mouse move %d %d'", screenW/2, screenH/2);
    runShell(cmd);
}

} // extern "C"
