#pragma once
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <mutex>
#include <thread>
#include <cmath>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <array>
#include <string>
#include <vector>
#include <functional>
#include <chrono>

#define TAG "KM_Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)

using Clock     = std::chrono::high_resolution_clock;
using TimePoint = std::chrono::time_point<Clock>;

// ── Ring buffer (lock-free SPSC) ─────────────────────────────────────────────
template<typename T, size_t N>
struct RingBuffer {
    bool push(const T& v) {
        size_t h = head.load(std::memory_order_relaxed);
        size_t nh = (h + 1) % N;
        if (nh == tail.load(std::memory_order_acquire)) return false;
        buf[h] = v;
        head.store(nh, std::memory_order_release);
        return true;
    }
    bool pop(T& v) {
        size_t t = tail.load(std::memory_order_relaxed);
        if (t == head.load(std::memory_order_acquire)) return false;
        v = buf[t];
        tail.store((t + 1) % N, std::memory_order_release);
        return true;
    }
    bool empty() const {
        return tail.load(std::memory_order_acquire) ==
               head.load(std::memory_order_acquire);
    }
    void clear() { tail.store(head.load(std::memory_order_acquire), std::memory_order_release); }
private:
    std::array<T, N> buf{};
    std::atomic<size_t> head{0}, tail{0};
};

// ── Touch event ───────────────────────────────────────────────────────────────
struct TouchEvent {
    enum Type : int { DOWN=0, MOVE=1, UP=2, CANCEL=3 } type;
    int   id;
    float x, y;
    float pressure;
    int64_t ts_ns;
};

// ── Mouse raw delta ───────────────────────────────────────────────────────────
struct MouseDelta {
    float dx, dy;
    bool  btn_left_down;
    bool  btn_left_up;
    bool  btn_right_down;
    bool  btn_right_up;
    int   wheel;
};

// ── Globals ───────────────────────────────────────────────────────────────────
extern RingBuffer<TouchEvent,  512> g_touchQueue;
extern RingBuffer<MouseDelta,  512> g_mouseQueue;

extern std::atomic<bool>  g_running;
extern std::atomic<float> g_sensitivity;
extern std::atomic<float> g_acceleration;
extern std::atomic<float> g_deadzone;
extern std::atomic<int>   g_screenW;
extern std::atomic<int>   g_screenH;
extern std::atomic<bool>  g_mouseLocked;

// helpers
static inline float clampf(float v, float lo, float hi) {
    return v < lo ? lo : v > hi ? hi : v;
}
static inline int64_t now_ns() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        Clock::now().time_since_epoch()).count();
}
static inline float apply_curve(float d, float sens, float accel) {
    float a = fabsf(d);
    float curved = a + a * a * accel * 0.008f;
    return copysignf(curved * sens, d);
}
static inline float apply_deadzone(float v, float dz) {
    float a = fabsf(v);
    if (a < dz) return 0.f;
    return copysignf((a - dz) / (1.f - dz), v);
}
