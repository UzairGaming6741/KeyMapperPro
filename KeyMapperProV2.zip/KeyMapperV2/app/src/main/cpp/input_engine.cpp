/**
 * input_engine.cpp
 *
 * Core input state machine.
 * - Converts WASD key states → joystick touch position
 * - Converts raw mouse deltas → aim drag events
 * - Manages all pointer slot assignments
 * - Aim lock: keeps pointer in middle of screen, moves relative
 * - Joystick: smooth analog output, diagonal normalised
 * - All paths zero-allocation in hot loop
 */
#include "native.h"

// ── Slot assignments ─────────────────────────────────────────────────────────
#define SLOT_JOYSTICK   0   // WASD movement
#define SLOT_AIM        1   // Mouse aim drag
#define SLOT_SHOOT      2   // Left click / fire
#define SLOT_SCOPE      3   // Right click / ADS
#define SLOT_BTN_BASE   4   // Keyboard buttons 4..9

// ── State ────────────────────────────────────────────────────────────────────
static std::atomic<bool> g_joyActive{false};
static std::atomic<bool> g_aimActive{false};
static std::atomic<bool> g_shootActive{false};
static std::atomic<bool> g_scopeActive{false};

// Aim position (absolute screen coords, updated each frame)
static std::atomic<float> g_aimX{0.f};
static std::atomic<float> g_aimY{0.f};
static std::atomic<float> g_aimCX{0.f};   // center (configurable)
static std::atomic<float> g_aimCY{0.f};

// Joystick center
static std::atomic<float> g_joyCX{0.f};
static std::atomic<float> g_joyCY{0.f};
static std::atomic<float> g_joyR{0.f};

// Button positions [slot-4 → index]
static float g_btnX[6]{};
static float g_btnY[6]{};
static bool  g_btnActive[6]{};

// WASD bits
static std::atomic<uint8_t> g_wasd{0};  // bit0=W bit1=A bit2=S bit3=D

// Tracking IDs (must be unique per uinput spec)
static int g_trackId = 100;
static int nextTrackId() { return g_trackId++; }

// Slot tracking IDs
static int g_slotTid[10]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};

static inline void pushDown(int slot, float x, float y) {
    g_slotTid[slot] = nextTrackId();
    TouchEvent e;
    e.type = TouchEvent::DOWN;
    e.id   = slot;
    e.x    = x; e.y = y;
    e.pressure = 1.f;
    e.ts_ns = now_ns();
    g_touchQueue.push(e);
}
static inline void pushMove(int slot, float x, float y) {
    TouchEvent e;
    e.type = TouchEvent::MOVE;
    e.id   = slot;
    e.x    = x; e.y = y;
    e.pressure = 1.f;
    e.ts_ns = now_ns();
    g_touchQueue.push(e);
}
static inline void pushUp(int slot, float x, float y) {
    TouchEvent e;
    e.type = TouchEvent::UP;
    e.id   = slot;
    e.x    = x; e.y = y;
    e.pressure = 0.f;
    e.ts_ns = now_ns();
    g_touchQueue.push(e);
    g_slotTid[slot] = -1;
}

// ── Joystick update ───────────────────────────────────────────────────────────
static void updateJoystick() {
    uint8_t wasd = g_wasd.load();
    float ax = 0.f, ay = 0.f;
    if (wasd & 1) ay -= 1.f;  // W
    if (wasd & 2) ax -= 1.f;  // A
    if (wasd & 4) ay += 1.f;  // S
    if (wasd & 8) ax += 1.f;  // D

    // Normalize diagonal
    float len = sqrtf(ax*ax + ay*ay);
    if (len > 1.f) { ax /= len; ay /= len; }

    float cx = g_joyCX.load(), cy = g_joyCY.load(), r = g_joyR.load();
    float tx = cx + ax * r;
    float ty = cy + ay * r;

    bool active = (len > 0.01f);

    if (!g_joyActive.load() && active) {
        pushDown(SLOT_JOYSTICK, tx, ty);
        g_joyActive.store(true);
    } else if (g_joyActive.load() && active) {
        pushMove(SLOT_JOYSTICK, tx, ty);
    } else if (g_joyActive.load() && !active) {
        pushUp(SLOT_JOYSTICK, cx, cy);
        g_joyActive.store(false);
    }
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeSetLayout(JNIEnv*, jobject,
        jfloat aimCX, jfloat aimCY,
        jfloat joyCX, jfloat joyCY, jfloat joyR,
        jfloat shootX, jfloat shootY,
        jfloat scopeX, jfloat scopeY) {

    g_aimCX.store(aimCX);  g_aimCY.store(aimCY);
    g_aimX.store(aimCX);   g_aimY.store(aimCY);
    g_joyCX.store(joyCX);  g_joyCY.store(joyCY);
    g_joyR.store(joyR);

    g_btnX[SLOT_SHOOT - SLOT_BTN_BASE + 2] = shootX; // hack: store shoot/scope separately
    g_btnY[SLOT_SHOOT - SLOT_BTN_BASE + 2] = shootY;
    g_btnX[SLOT_SCOPE - SLOT_BTN_BASE + 2] = scopeX;
    g_btnY[SLOT_SCOPE - SLOT_BTN_BASE + 2] = scopeY;

    LOGI("Layout set: aim(%.0f,%.0f) joy(%.0f,%.0f,r=%.0f)",
         aimCX, aimCY, joyCX, joyCY, joyR);
}

JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeSetButtonPos(JNIEnv*, jobject,
        jint idx, jfloat x, jfloat y) {
    if (idx < 0 || idx >= 6) return;
    g_btnX[idx] = x;
    g_btnY[idx] = y;
}

// Called by EvdevEngine poll loop when mouse delta arrives
JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeOnMouseDelta(JNIEnv*, jobject,
        jfloat rawDx, jfloat rawDy) {

    float sens  = g_sensitivity.load();
    float accel = g_acceleration.load();
    float dx = apply_curve(rawDx, sens, accel);
    float dy = apply_curve(rawDy, sens, accel);

    float sw = (float)g_screenW.load();
    float sh = (float)g_screenH.load();

    float newX = clampf(g_aimX.load() + dx, 0.f, sw);
    float newY = clampf(g_aimY.load() + dy, 0.f, sh);
    g_aimX.store(newX);
    g_aimY.store(newY);

    if (!g_aimActive.load()) {
        pushDown(SLOT_AIM, newX, newY);
        g_aimActive.store(true);
    } else {
        pushMove(SLOT_AIM, newX, newY);
    }
}

JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeStopAim(JNIEnv*, jobject) {
    if (g_aimActive.load()) {
        pushUp(SLOT_AIM, g_aimX.load(), g_aimY.load());
        g_aimActive.store(false);
        // Snap aim back to center
        g_aimX.store(g_aimCX.load());
        g_aimY.store(g_aimCY.load());
    }
}

JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeOnMouseButton(JNIEnv*, jobject,
        jboolean leftDown, jboolean leftUp,
        jboolean rightDown, jboolean rightUp) {

    // Left = Shoot
    float sx = g_btnX[2], sy = g_btnY[2]; // shoot pos
    if (leftDown && !g_shootActive.load()) {
        pushDown(SLOT_SHOOT, sx, sy);
        g_shootActive.store(true);
    }
    if (leftUp && g_shootActive.load()) {
        pushUp(SLOT_SHOOT, sx, sy);
        g_shootActive.store(false);
    }

    // Right = ADS/Scope
    float ax = g_btnX[3], ay = g_btnY[3]; // scope pos
    if (rightDown && !g_scopeActive.load()) {
        pushDown(SLOT_SCOPE, ax, ay);
        g_scopeActive.store(true);
    }
    if (rightUp && g_scopeActive.load()) {
        pushUp(SLOT_SCOPE, ax, ay);
        g_scopeActive.store(false);
    }
}

// evdev key code → WASD bit
static int linuxKeyToWasdBit(int code) {
    switch(code) {
        case KEY_W: return 1;
        case KEY_A: return 2;
        case KEY_S: return 4;
        case KEY_D: return 8;
    }
    return 0;
}

JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeOnKey(JNIEnv*, jobject,
        jint code, jint value) {
    // value: 1=press, 0=release, 2=repeat
    int bit = linuxKeyToWasdBit(code);
    if (bit) {
        uint8_t cur = g_wasd.load();
        if (value >= 1) cur |=  (uint8_t)bit;
        else            cur &= ~(uint8_t)bit;
        g_wasd.store(cur);
        updateJoystick();
        return;
    }

    // Other mapped keys → button slots
    // handled by Kotlin layer mapping table
}

JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeButtonDown(JNIEnv*, jobject,
        jint slotIdx, jfloat x, jfloat y) {
    int slot = SLOT_BTN_BASE + slotIdx;
    if (slot > 9) return;
    if (g_btnActive[slotIdx]) return;
    g_btnX[slotIdx] = x;
    g_btnY[slotIdx] = y;
    pushDown(slot, x, y);
    g_btnActive[slotIdx] = true;
}

JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeButtonUp(JNIEnv*, jobject,
        jint slotIdx) {
    int slot = SLOT_BTN_BASE + slotIdx;
    if (slot > 9) return;
    if (!g_btnActive[slotIdx]) return;
    pushUp(slot, g_btnX[slotIdx], g_btnY[slotIdx]);
    g_btnActive[slotIdx] = false;
}

JNIEXPORT void JNICALL
Java_com_keymapper_engine_InputEngine_nativeReleaseAll(JNIEnv*, jobject) {
    if (g_joyActive.load())  { pushUp(SLOT_JOYSTICK, g_joyCX.load(), g_joyCY.load()); g_joyActive.store(false); }
    if (g_aimActive.load())  { pushUp(SLOT_AIM, g_aimX.load(), g_aimY.load()); g_aimActive.store(false); }
    if (g_shootActive.load()){ pushUp(SLOT_SHOOT, g_btnX[2], g_btnY[2]); g_shootActive.store(false); }
    if (g_scopeActive.load()){ pushUp(SLOT_SCOPE, g_btnX[3], g_btnY[3]); g_scopeActive.store(false); }
    for (int i = 0; i < 6; i++) {
        if (g_btnActive[i]) { pushUp(SLOT_BTN_BASE+i, g_btnX[i], g_btnY[i]); g_btnActive[i] = false; }
    }
    g_wasd.store(0);
    LOGI("All inputs released");
}

} // extern "C"
