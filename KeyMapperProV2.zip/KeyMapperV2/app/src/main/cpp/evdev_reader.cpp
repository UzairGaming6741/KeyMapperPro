/**
 * evdev_reader.cpp
 *
 * Reads raw mouse/keyboard events directly from /dev/input/eventX
 * using the Linux evdev API.  This runs BEFORE Android's input system
 * sees anything — giving us true raw delta mouse tracking and the ability
 * to suppress cursor movement entirely (mouse lock).
 *
 * Requires root to open /dev/input/* devices.
 */

#include "native.h"

// ── Globals defined here ──────────────────────────────────────────────────────
RingBuffer<TouchEvent,  512> g_touchQueue;
RingBuffer<MouseDelta,  512> g_mouseQueue;
std::atomic<bool>  g_running{false};
std::atomic<float> g_sensitivity{1.8f};
std::atomic<float> g_acceleration{0.3f};
std::atomic<float> g_deadzone{0.10f};
std::atomic<int>   g_screenW{1920};
std::atomic<int>   g_screenH{1080};
std::atomic<bool>  g_mouseLocked{false};

// ── evdev device discovery ────────────────────────────────────────────────────
static std::string findMouseDevice() {
    DIR* dir = opendir("/dev/input");
    if (!dir) { LOGE("Cannot open /dev/input — need root"); return ""; }

    dirent* ent;
    while ((ent = readdir(dir)) != nullptr) {
        if (strncmp(ent->d_name, "event", 5) != 0) continue;

        std::string path = std::string("/dev/input/") + ent->d_name;
        int fd = open(path.c_str(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) continue;

        char name[256] = {};
        ioctl(fd, EVIOCGNAME(sizeof(name)), name);

        // Check for relative axis capability (mouse)
        uint8_t evbits[(EV_MAX + 7) / 8] = {};
        ioctl(fd, EVIOCGBIT(0, sizeof(evbits)), evbits);

        bool hasRel = (evbits[EV_REL / 8] >> (EV_REL % 8)) & 1;
        bool hasKey = (evbits[EV_KEY / 8] >> (EV_KEY % 8)) & 1;

        if (hasRel && hasKey) {
            // Check REL_X and REL_Y
            uint8_t relbits[(REL_MAX + 7) / 8] = {};
            ioctl(fd, EVIOCGBIT(EV_REL, sizeof(relbits)), relbits);
            bool hasX = (relbits[REL_X / 8] >> (REL_X % 8)) & 1;
            bool hasY = (relbits[REL_Y / 8] >> (REL_Y % 8)) & 1;

            if (hasX && hasY) {
                LOGI("Found mouse: %s (%s)", path.c_str(), name);
                close(fd);
                closedir(dir);
                return path;
            }
        }
        close(fd);
    }
    closedir(dir);
    return "";
}

static std::string findKeyboardDevice() {
    DIR* dir = opendir("/dev/input");
    if (!dir) return "";

    dirent* ent;
    while ((ent = readdir(dir)) != nullptr) {
        if (strncmp(ent->d_name, "event", 5) != 0) continue;
        std::string path = std::string("/dev/input/") + ent->d_name;
        int fd = open(path.c_str(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) continue;

        uint8_t evbits[(EV_MAX + 7) / 8] = {};
        ioctl(fd, EVIOCGBIT(0, sizeof(evbits)), evbits);
        bool hasKey = (evbits[EV_KEY / 8] >> (EV_KEY % 8)) & 1;
        bool hasRel = (evbits[EV_REL / 8] >> (EV_REL % 8)) & 1;

        // Keyboard: has keys but NOT relative axes
        if (hasKey && !hasRel) {
            uint8_t keybits[(KEY_MAX + 7) / 8] = {};
            ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(keybits)), keybits);
            // Check KEY_A exists (basic keyboard check)
            if ((keybits[KEY_A / 8] >> (KEY_A % 8)) & 1) {
                char name[256] = {};
                ioctl(fd, EVIOCGNAME(sizeof(name)), name);
                LOGI("Found keyboard: %s (%s)", path.c_str(), name);
                close(fd);
                closedir(dir);
                return path;
            }
        }
        close(fd);
    }
    closedir(dir);
    return "";
}

// ── Mouse lock: grab device so Android cursor system can't see events ─────────
static int g_mouseFd = -1;
static int g_keyboardFd = -1;

static bool grabDevice(int fd) {
    if (ioctl(fd, EVIOCGRAB, 1) == 0) {
        LOGI("Device grabbed (mouse locked)");
        return true;
    }
    LOGE("EVIOCGRAB failed — check root");
    return false;
}

static void releaseDevice(int fd) {
    ioctl(fd, EVIOCGRAB, 0);
    LOGI("Device released (mouse unlocked)");
}

// ── Mouse reading thread ──────────────────────────────────────────────────────
static std::thread g_mouseThread;
static std::thread g_keyThread;

static void mouseReadLoop(int fd) {
    struct input_event ev[32];
    float accDx = 0.f, accDy = 0.f;

    while (g_running.load()) {
        ssize_t n = read(fd, ev, sizeof(ev));
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                std::this_thread::sleep_for(std::chrono::microseconds(500));
                continue;
            }
            LOGE("Mouse read error: %s", strerror(errno));
            break;
        }

        int count = n / sizeof(struct input_event);
        MouseDelta delta{};
        bool hasDelta = false;

        for (int i = 0; i < count; i++) {
            auto& e = ev[i];
            switch (e.type) {
                case EV_REL:
                    if (e.code == REL_X) { accDx += (float)e.value; hasDelta = true; }
                    if (e.code == REL_Y) { accDy += (float)e.value; hasDelta = true; }
                    break;
                case EV_KEY:
                    if (e.code == BTN_LEFT) {
                        if (e.value == 1) delta.btn_left_down  = true;
                        else              delta.btn_left_up    = true;
                        hasDelta = true;
                    }
                    if (e.code == BTN_RIGHT) {
                        if (e.value == 1) delta.btn_right_down = true;
                        else              delta.btn_right_up   = true;
                        hasDelta = true;
                    }
                    break;
                case EV_SYN:
                    if (e.code == SYN_REPORT && hasDelta) {
                        delta.dx = accDx;
                        delta.dy = accDy;
                        accDx = accDy = 0.f;
                        g_mouseQueue.push(delta);
                        delta = {};
                        hasDelta = false;
                    }
                    break;
            }
        }
    }
    LOGI("Mouse read loop exited");
}

// ── Keyboard reading thread ───────────────────────────────────────────────────
// Key events are forwarded to Java via a callback queue
struct KeyEvt { int code; int value; }; // value: 1=down,0=up,2=repeat
static RingBuffer<KeyEvt, 256> g_keyQueue;

static void keyReadLoop(int fd) {
    struct input_event ev[32];
    while (g_running.load()) {
        ssize_t n = read(fd, ev, sizeof(ev));
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                std::this_thread::sleep_for(std::chrono::microseconds(500));
                continue;
            }
            break;
        }
        int count = n / sizeof(struct input_event);
        for (int i = 0; i < count; i++) {
            if (ev[i].type == EV_KEY) {
                g_keyQueue.push({(int)ev[i].code, (int)ev[i].value});
            }
        }
    }
}

// ── JNI exports ──────────────────────────────────────────────────────────────
extern "C" {

JNIEXPORT jint JNICALL
Java_com_keymapper_evdev_EvdevEngine_nativeStart(JNIEnv*, jobject, jint sw, jint sh) {
    g_screenW.store(sw);
    g_screenH.store(sh);
    g_running.store(true);
    g_touchQueue.clear();
    g_mouseQueue.clear();

    std::string mousePath = findMouseDevice();
    if (mousePath.empty()) {
        LOGE("No mouse device found");
        return -1;
    }

    g_mouseFd = open(mousePath.c_str(), O_RDONLY | O_NONBLOCK);
    if (g_mouseFd < 0) { LOGE("Cannot open mouse: %s", strerror(errno)); return -2; }

    std::string kbPath = findKeyboardDevice();
    if (!kbPath.empty()) {
        g_keyboardFd = open(kbPath.c_str(), O_RDONLY | O_NONBLOCK);
        if (g_keyboardFd >= 0) {
            g_keyThread = std::thread(keyReadLoop, g_keyboardFd);
        }
    }

    g_mouseThread = std::thread(mouseReadLoop, g_mouseFd);
    LOGI("EvdevEngine started — mouse:%s", mousePath.c_str());
    return 0;
}

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_EvdevEngine_nativeStop(JNIEnv*, jobject) {
    g_running.store(false);
    if (g_mouseFd >= 0) { releaseDevice(g_mouseFd); close(g_mouseFd); g_mouseFd = -1; }
    if (g_keyboardFd >= 0) { releaseDevice(g_keyboardFd); close(g_keyboardFd); g_keyboardFd = -1; }
    if (g_mouseThread.joinable()) g_mouseThread.join();
    if (g_keyThread.joinable())   g_keyThread.join();
    LOGI("EvdevEngine stopped");
}

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_EvdevEngine_nativeSetMouseLock(JNIEnv*, jobject, jboolean lock) {
    if (g_mouseFd < 0) return;
    if (lock) grabDevice(g_mouseFd);
    else      releaseDevice(g_mouseFd);
    g_mouseLocked.store(lock);
}

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_EvdevEngine_nativeSetConfig(JNIEnv*, jobject,
        jfloat sens, jfloat accel, jfloat dz, jint sw, jint sh) {
    g_sensitivity.store(sens);
    g_acceleration.store(accel);
    g_deadzone.store(dz);
    g_screenW.store(sw);
    g_screenH.store(sh);
}

JNIEXPORT jboolean JNICALL
Java_com_keymapper_evdev_EvdevEngine_nativePollMouse(JNIEnv* env, jobject,
        jfloatArray outDxDy, jbooleanArray outButtons) {
    MouseDelta d;
    if (!g_mouseQueue.pop(d)) return JNI_FALSE;

    jfloat dd[2] = { d.dx, d.dy };
    env->SetFloatArrayRegion(outDxDy, 0, 2, dd);

    jboolean btns[4] = {
        d.btn_left_down  ? JNI_TRUE : JNI_FALSE,
        d.btn_left_up    ? JNI_TRUE : JNI_FALSE,
        d.btn_right_down ? JNI_TRUE : JNI_FALSE,
        d.btn_right_up   ? JNI_TRUE : JNI_FALSE
    };
    env->SetBooleanArrayRegion(outButtons, 0, 4, btns);
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_keymapper_evdev_EvdevEngine_nativePollKey(JNIEnv* env, jobject,
        jintArray outCodeVal) {
    KeyEvt k;
    if (!g_keyQueue.pop(k)) return JNI_FALSE;
    jint cv[2] = { k.code, k.value };
    env->SetIntArrayRegion(outCodeVal, 0, 2, cv);
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_keymapper_evdev_EvdevEngine_nativePollTouch(JNIEnv* env, jobject,
        jintArray outType, jintArray outId,
        jfloatArray outX, jfloatArray outY) {
    TouchEvent t;
    if (!g_touchQueue.pop(t)) return JNI_FALSE;
    jint type = t.type, id = t.id;
    jfloat x = t.x, y = t.y;
    env->SetIntArrayRegion(outType, 0, 1, &type);
    env->SetIntArrayRegion(outId,   0, 1, &id);
    env->SetFloatArrayRegion(outX,  0, 1, &x);
    env->SetFloatArrayRegion(outY,  0, 1, &y);
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_keymapper_evdev_EvdevEngine_nativeIsMouseLocked(JNIEnv*, jobject) {
    return g_mouseLocked.load() ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"
