/**
 * uinput_touch.cpp
 *
 * Creates a virtual multi-touch device via /dev/uinput.
 * This injects touch events directly into the Linux input subsystem,
 * bypassing Android's AccessibilityService entirely.
 * This is the same method emulators use for guaranteed touch injection.
 *
 * Requires root.
 */
#include "native.h"

static int g_uinputFd = -1;
static bool g_uinputReady = false;

// Screen dimensions for ABS range
static int g_sw = 1920, g_sh = 1080;
#define MAX_CONTACTS 10

static void writeEvent(int fd, int type, int code, int value) {
    struct input_event ev{};
    ev.type  = type;
    ev.code  = code;
    ev.value = value;
    write(fd, &ev, sizeof(ev));
}

static void sync(int fd) {
    writeEvent(fd, EV_SYN, SYN_REPORT, 0);
}

static void mtSync(int fd) {
    writeEvent(fd, EV_SYN, SYN_MT_REPORT, 0);
}

extern "C" {

JNIEXPORT jint JNICALL
Java_com_keymapper_evdev_UInputTouch_nativeCreate(JNIEnv*, jobject, jint sw, jint sh) {
    g_sw = sw; g_sh = sh;

    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    if (fd < 0) {
        LOGE("Cannot open /dev/uinput: %s", strerror(errno));
        return -1;
    }

    // Enable event types
    ioctl(fd, UI_SET_EVBIT, EV_KEY);
    ioctl(fd, UI_SET_EVBIT, EV_ABS);
    ioctl(fd, UI_SET_EVBIT, EV_SYN);
    ioctl(fd, UI_SET_KEYBIT, BTN_TOUCH);
    ioctl(fd, UI_SET_KEYBIT, BTN_TOOL_FINGER);

    // MT axes
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_SLOT);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_X);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_Y);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_PRESSURE);
    ioctl(fd, UI_SET_ABSBIT, ABS_X);
    ioctl(fd, UI_SET_ABSBIT, ABS_Y);

    struct uinput_user_dev uidev{};
    snprintf(uidev.name, UINPUT_MAX_NAME_SIZE, "KeyMapper Virtual Touch");
    uidev.id.bustype = BUS_VIRTUAL;
    uidev.id.vendor  = 0x1234;
    uidev.id.product = 0x5678;
    uidev.id.version = 1;

    // Set ranges
    uidev.absmin[ABS_MT_SLOT]        = 0;
    uidev.absmax[ABS_MT_SLOT]        = MAX_CONTACTS - 1;
    uidev.absmin[ABS_MT_TRACKING_ID] = -1;
    uidev.absmax[ABS_MT_TRACKING_ID] = 65535;
    uidev.absmin[ABS_MT_POSITION_X]  = 0;
    uidev.absmax[ABS_MT_POSITION_X]  = sw;
    uidev.absmin[ABS_MT_POSITION_Y]  = 0;
    uidev.absmax[ABS_MT_POSITION_Y]  = sh;
    uidev.absmin[ABS_MT_PRESSURE]    = 0;
    uidev.absmax[ABS_MT_PRESSURE]    = 255;
    uidev.absmin[ABS_X]              = 0;
    uidev.absmax[ABS_X]              = sw;
    uidev.absmin[ABS_Y]              = 0;
    uidev.absmax[ABS_Y]              = sh;

    if (write(fd, &uidev, sizeof(uidev)) < 0) {
        LOGE("uinput write failed: %s", strerror(errno));
        close(fd);
        return -2;
    }
    if (ioctl(fd, UI_DEV_CREATE) < 0) {
        LOGE("UI_DEV_CREATE failed: %s", strerror(errno));
        close(fd);
        return -3;
    }

    g_uinputFd = fd;
    g_uinputReady = true;
    LOGI("uinput virtual touch device created (%dx%d)", sw, sh);
    return 0;
}

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_UInputTouch_nativeDestroy(JNIEnv*, jobject) {
    if (g_uinputFd >= 0) {
        ioctl(g_uinputFd, UI_DEV_DESTROY);
        close(g_uinputFd);
        g_uinputFd = -1;
        g_uinputReady = false;
        LOGI("uinput device destroyed");
    }
}

// slot=0..9, trackingId=-1 means finger up
JNIEXPORT void JNICALL
Java_com_keymapper_evdev_UInputTouch_nativeTouchDown(JNIEnv*, jobject,
        jint slot, jint trackingId, jint x, jint y) {
    if (!g_uinputReady) return;
    int fd = g_uinputFd;
    writeEvent(fd, EV_ABS, ABS_MT_SLOT,        slot);
    writeEvent(fd, EV_ABS, ABS_MT_TRACKING_ID, trackingId);
    writeEvent(fd, EV_ABS, ABS_MT_POSITION_X,  x);
    writeEvent(fd, EV_ABS, ABS_MT_POSITION_Y,  y);
    writeEvent(fd, EV_ABS, ABS_MT_PRESSURE,    200);
    if (slot == 0) {
        writeEvent(fd, EV_KEY, BTN_TOUCH, 1);
        writeEvent(fd, EV_ABS, ABS_X, x);
        writeEvent(fd, EV_ABS, ABS_Y, y);
    }
    sync(fd);
}

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_UInputTouch_nativeTouchMove(JNIEnv*, jobject,
        jint slot, jint x, jint y) {
    if (!g_uinputReady) return;
    int fd = g_uinputFd;
    writeEvent(fd, EV_ABS, ABS_MT_SLOT,       slot);
    writeEvent(fd, EV_ABS, ABS_MT_POSITION_X, x);
    writeEvent(fd, EV_ABS, ABS_MT_POSITION_Y, y);
    if (slot == 0) {
        writeEvent(fd, EV_ABS, ABS_X, x);
        writeEvent(fd, EV_ABS, ABS_Y, y);
    }
    sync(fd);
}

JNIEXPORT void JNICALL
Java_com_keymapper_evdev_UInputTouch_nativeTouchUp(JNIEnv*, jobject, jint slot) {
    if (!g_uinputReady) return;
    int fd = g_uinputFd;
    writeEvent(fd, EV_ABS, ABS_MT_SLOT,        slot);
    writeEvent(fd, EV_ABS, ABS_MT_TRACKING_ID, -1);
    writeEvent(fd, EV_ABS, ABS_MT_PRESSURE,    0);
    if (slot == 0) writeEvent(fd, EV_KEY, BTN_TOUCH, 0);
    sync(fd);
}

JNIEXPORT jboolean JNICALL
Java_com_keymapper_evdev_UInputTouch_nativeIsReady(JNIEnv*, jobject) {
    return g_uinputReady ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"
