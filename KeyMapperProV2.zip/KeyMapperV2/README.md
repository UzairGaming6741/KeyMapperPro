# KeyMapper Pro V2 — Root Edition
## Built for POSROG V3U8 · Free Fire · PUBG Mobile · COD Mobile

---

## What's Different From V1 (Why This Works)

| V1 (Old) | V2 (This) |
|---|---|
| Accessibility Service gesture injection | Direct `/dev/uinput` kernel injection |
| Android cursor still visible | Cursor fully hidden via EVIOCGRAB |
| Aim could get stuck | evdev raw delta — never sticks |
| Mouse could escape screen | Kernel grab = cursor doesn't move AT ALL |
| No true mouse lock | Full EVIOCGRAB mouse lock |

---

## How It Works (Technical)

```
Physical Mouse
      │
      ▼
/dev/input/eventX  ◄── evdev_reader.cpp reads raw EV_REL events
      │                 EVIOCGRAB = Android sees NOTHING
      ▼
input_engine.cpp   ◄── Converts dx/dy → touch positions
      │                 WASD → joystick axes
      │                 Mouse buttons → shoot/scope taps
      ▼
/dev/uinput        ◄── uinput_touch.cpp injects ABS_MT multitouch
      │
      ▼
Android game receives clean multitouch events
(same as real finger touches)
```

---

## Build Instructions

### 1. Prerequisites
- Android Studio (latest)
- NDK (Side by side) — install via SDK Manager → SDK Tools
- CMake 3.22.1 — install via SDK Manager → SDK Tools
- JDK 17

### 2. Open Project
```
Android Studio → Open → select KeyMapperV2 folder
Wait for Gradle sync
```

### 3. Build APK
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
Output: app/build/outputs/apk/debug/app-debug.apk
```

### 4. Install on POSROG
```bash
adb connect <posrog-ip>:5555
adb install app-debug.apk
```
Or copy APK to POSROG and tap to install.

---

## First-Time Setup on POSROG

1. Install APK
2. Open **KeyMapper Pro**
3. Tap **Enable Accessibility Service** → enable it
4. Return to app — service shows green ✓
5. Select your game preset (Free Fire / PUBG / COD)
6. Open your game
7. Tap **▶ Start Mapping**
8. Grant root when prompted (Magisk popup)

---

## Default Controls

### Free Fire / PUBG / COD

| Input | Action |
|-------|--------|
| `W` | Move forward |
| `A` | Move left |
| `S` | Move back |
| `D` | Move right |
| Mouse Move | Aim camera |
| **Left Click** | **Fire / Shoot** |
| **Right Click** | **ADS / Scope** |
| `Space` | Jump |
| `C` (hold) | Crouch |
| `Z` | Prone |
| `R` | Reload |
| `F` | Loot / Interact |
| `M` | Map |
| `Tab` | Inventory |
| `V` | Enter vehicle |

### Mouse Lock Toggle
The mouse is **automatically locked** when mapping starts.
To unlock temporarily (e.g. for menus):
- **Stop Mapping** in the app, or
- Add a toggle key (Right Alt by default) in a future update

---

## Troubleshooting

**Root grant popup doesn't appear**
→ Open Magisk → make sure "Root requests" is enabled
→ Try running `su` in Termux to verify root works

**evdev start failed (-1)**
→ Run in Termux: `ls -la /dev/input/` — check permissions
→ Run: `su -c 'ls -la /dev/input/'` — should show mouse

**uinput failed (-1)**
→ Run: `su -c 'ls -la /dev/uinput'` — must exist
→ If missing: `su -c 'modprobe uinput'`

**Aim still sticks**
→ Increase deadzone in Settings to 0.15
→ Reduce sensitivity to 1.5

**No movement in game**
→ Make sure joystick center is positioned over the joystick zone in-game
→ Open Overlay Editor and move the joystick position

**Controls feel off**
→ Go to Settings and tune sensitivity (start at 2.0 for Free Fire, 1.8 for PUBG)

---

## Key Files

```
app/src/main/cpp/
├── evdev_reader.cpp     ← Reads /dev/input, grabs mouse (ROOT)
├── uinput_touch.cpp     ← Injects touch via /dev/uinput (ROOT)
├── input_engine.cpp     ← WASD→joystick, mouse→aim state machine
├── mouse_lock.cpp       ← Hides cursor via root shell

app/src/main/java/com/keymapper/
├── engine/
│   ├── GameController.kt   ← Master loop, ties everything together
│   ├── InputEngine.kt      ← JNI bridge
│   └── KeyBinding.kt       ← All game presets (FF, PUBG, COD, BR)
├── evdev/
│   ├── EvdevEngine.kt      ← JNI bridge to evdev reader
│   ├── UInputTouch.kt      ← JNI bridge to uinput
│   └── MouseLock.kt        ← JNI bridge to mouse lock
├── profile/
│   └── ProfileManager.kt   ← Save/load profiles
├── service/
│   └── KeyMapperService.kt ← AccessibilityService host
└── ui/
    ├── MainActivity.kt     ← Main screen
    ├── EditorActivity.kt   ← Drag & drop key editor
    ├── ProfilesActivity.kt ← Profile list
    └── SettingsActivity.kt ← Sensitivity / deadzone
```
